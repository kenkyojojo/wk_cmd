#!/bin/ksh
#
#----------------------------------
# Set variable
#----------------------------------
hostname=`hostname`
DATE2=`date +%Y%m`
SHDIR=/home/se/safechk/safesh
LOGDIR=/home/se/safechk/safelog
LOG=/home/se/safechk/safesh/dailycheck/dailycheck.log
FILESH=/home/se/safechk/safesh/dailycheck/fileaudit
ACCOUNTSH=/home/se/safechk/safesh/dailycheck/account
FILEDIR=/home/se/safechk/file/fileaudit
ACCOUNTDIR=/home/se/safechk/file/account

#---------------------
# Daily file check
#---------------------
STEP1() {
   echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'File Check Start' >> $LOG
   $FILESH/filecheck.sh > $LOGDIR/safelog.${hostname}.fileattr.`date +%Y%m%d` 2> $FILEDIR/err/safelog.${hostname}.fileattr.`date +%Y%m%d.err`
   chown useradm:security $LOGDIR/safelog.${hostname}.fileattr.`date +%Y%m%d`
   chown -R useradm:security $FILEDIR/*
   cat $LOGDIR/safelog.${hostname}.fileattr.`date +%Y%m%d`

   find $FILEDIR/check -type f -mtime +14 -exec rm {} \;
   find $FILEDIR/result -type f -mtime +14 -exec rm {} \;
   find $FILEDIR/err -type f -mtime +14 -exec rm {} \;
   echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'File Check End' >> $LOG
}

#---------------------
# User account check
#---------------------
STEP2() {
   echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'Account Check Start' >> $LOG
   $ACCOUNTSH/chkaccount.sh > $LOGDIR/safelog.${hostname}.account.`date +%Y%m%d` 2> $ACCOUNTDIR/err/safelog.${hostname}.account.`date +%Y%m%d.err`
   chown useradm:security $LOGDIR/safelog.${hostname}.account.`date +%Y%m%d`
   chown -R useradm:security $ACCOUNTDIR/*
   cat $LOGDIR/safelog.${hostname}.account.`date +%Y%m%d`

   find $ACCOUNTDIR/check -type f -mtime +14 -exec rm {} \;
   find $ACCOUNTDIR/result -type f -mtime +14 -exec rm {} \;
   find $ACCOUNTDIR/err -type f -mtime +14 -exec rm {} \;
   echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'Account Check End' >> $LOG
}

#----------------------
# output to safelog
#----------------------
STEP3() {
   echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'safelog Start' >> $LOG
   $SHDIR/safelog.sh
   chown useradm:security $LOGDIR/*.txt
   echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'safelog End' >> $LOG
}

#----------------------
# resort log to csv
#----------------------
STEP4() {
   echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'resort Start' >> $LOG
   $SHDIR/resort.sh
   chown useradm:security $LOGDIR/*.txt
   chown useradm:security $LOGDIR/*.csv
   echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'resort End' >> $LOG
}

#-----------------------
# Backup syslog and crontab(root)
#-----------------------
STEP5(){
   echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'Backup syslog and crontab(root) Start' >> $LOG
   LOGPATH="/var/log/syslog"
   if [ -d $LOGPATH ]; then
      cd $LOGPATH
      crontab -l > ${hostname}.crontab.txt
      tar -cf - ./* | gzip > ${hostname}.syslog.tar.gz
      echo Date: `date +%Y/%m/%d\ %H:%M:%S` 'Backup syslog and crontab(root) End' >> $LOG
   else
      echo Date: `date +%Y/%m/%d\ %H:%M:%S` '/var/log/syslog directory not exist' >> $LOG
   fi
}


STEP1
STEP2
STEP3
STEP4
STEP5

exit
