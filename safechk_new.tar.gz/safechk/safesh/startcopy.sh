#! /usr/bin/ksh
#
#----------------------------------
# Set variable
#----------------------------------
HOSTLIST=`cat /home/se/safechk/cfg/host.lst`
LOG=/home/se/safechk/safesh/dailycheck/dailycheck.log
USER=$(whoami)
HOMEDIR=`lsuser $USER | awk '{print $5}' | cut -c6-`


#----------------------------------
# Start remote copy filecheck file
#----------------------------------
for HOST in $HOSTLIST ; do
   ssh -p 2222 $HOST "/home/se/safechk/safesh/dailycheck/daily_copy.sh"
   execStatus=$?
   if [ $execStatus -eq 0 ]; then
      echo Date: `date +%Y/%m/%d\ %H:%M:%S` "$HOST COPY OK!" >> $LOG
   else
      echo Date: `date +%Y/%m/%d\ %H:%M:%S` "$HOST COPY Fail!" >> $LOG
   fi
done

exit 0
